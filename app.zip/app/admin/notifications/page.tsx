export default function NotificationsPage() {
  return (
    <div className="min-h-screen bg-[#f8fafc] p-8">
      <h1 className="text-4xl font-bold">Notifications</h1>
      <p className="mt-4 text-slate-600">Coming soon...</p>
    </div>
  )
}
